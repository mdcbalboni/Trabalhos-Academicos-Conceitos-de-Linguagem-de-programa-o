#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{
	int *vetor,i,j,aux,menor;
	vetor = malloc(sizeof(int)*100);
	srand(time(NULL));

	for (i = 0; i < 100; i++)
	{
		vetor[i]=rand()%100;
	}

	for (i = 0; i < 99; i++)
	{
		menor=i;
		for (j = i+1; j < 100; j++)
		{
			if (vetor[j]<vetor[menor])
			{
				menor=j;
			}
		}
		if(i!=menor)
		{
			aux=vetor[i];
			vetor[i]=vetor[menor];
			vetor[menor]=aux;
		}
	}
	for (i = 0; i < 100; i++)
	{
		printf("%d ",vetor[i]);
	}
	return 0;
}
