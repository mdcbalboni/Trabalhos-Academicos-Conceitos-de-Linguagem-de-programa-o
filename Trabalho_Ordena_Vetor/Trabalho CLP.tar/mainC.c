#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void ordena_(int *v);

int main()
{
	int *vetor,i;
	vetor = malloc(sizeof(int)*100);
	srand(time(NULL));
	for (i = 0; i < 100; i++)
	{
		vetor[i]=rand()%100;
	}
	ordena_(vetor);
	for (i = 0; i < 100; i++)
	{
		printf("%d ",vetor[i]);
	}
	printf("\n");
	return 0;
}
