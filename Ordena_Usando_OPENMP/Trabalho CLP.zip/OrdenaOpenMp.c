#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>


void funcao(int,int );
void imprime(int,int *);
pthread_mutex_t mutexTEX;

typedef struct BUCKETS
{
	int * values;
	int tam;
}Buckets;

void ordena(Buckets *,int);


int main()
{
	
	srand(time(NULL));
	 //funcao(10,1);
	//funcao(10,2);
	 //funcao(10,4);
	 funcao(100000,8);
	// pthread_mutex_init(&mutexTEX, NULL);
	
	return 0;
}

void funcao(int arraySize, int nmbBuckets)
{
	int i,array[arraySize],auxMAIOR; 
	//pthread_t thread[nmbBuckets];
	for (i = 0; i < arraySize; i++)
		array[i]=rand()%RAND_MAX;
	auxMAIOR=RAND_MAX/nmbBuckets;
	//aux = arraySize/nmbBuckets;
	Buckets bcks[nmbBuckets];
	
	//Alocando os baldes
	for(i=0;i<nmbBuckets;i++){
		bcks[i].values = calloc(arraySize,sizeof(int));
		bcks[i].tam=0;
	}
		//deu.
	switch(nmbBuckets)
	{
		case 1:   
		{
			for(i=0;i<arraySize;i++){
				bcks[0].values[i]=array[i];
			}
			break;
		}
		case 2: 
		{
			for(i=0;i<arraySize;i++)
				if(array[i] < auxMAIOR)
				{
					bcks[0].values[bcks[0].tam]=array[i];
					bcks[0].tam++;
				}
				else
				{
					bcks[1].values[bcks[1].tam]=array[i];
					bcks[1].tam++;
				}
		break;
		}
		case 4:
		{
			for(i=0;i<arraySize;i++)
				if(array[i] < auxMAIOR)
				{
					bcks[0].values[bcks[0].tam]=array[i];
					bcks[0].tam++;
				}
				else if(array[i]>=auxMAIOR  && array[i]<auxMAIOR*2) //
				{
					bcks[1].values[bcks[1].tam]=array[i];
					bcks[1].tam++;
				}
				else if(array[i]>=auxMAIOR*2  && array[i]<auxMAIOR*3)
				{ //
					bcks[2].values[bcks[2].tam]=array[i];
					bcks[2].tam++;
				}else{
					bcks[3].values[bcks[3].tam]=array[i];
					bcks[3].tam++;
			}
		break;
		}
		case 8:
		{

			for(i=0;i<arraySize;i++)
				if(array[i] < auxMAIOR) 
				{
					bcks[0].values[bcks[0].tam]=array[i];
					bcks[0].tam++;
				}
				else if(array[i]>=auxMAIOR  && array[i]<auxMAIOR*2) 
				{
					bcks[1].values[bcks[1].tam]=array[i];
					bcks[1].tam++;
				}
				else if(array[i]>=auxMAIOR*2  && array[i]<auxMAIOR*3)
				{ 
					bcks[2].values[bcks[2].tam]=array[i];
					bcks[2].tam++;
				}
				else if(array[i]>=auxMAIOR*3  && array[i]<auxMAIOR*4)
				{ 
					bcks[3].values[bcks[3].tam]=array[i];
					bcks[3].tam++;
				}
					else if(array[i]>=auxMAIOR*4  && array[i]<auxMAIOR*5)
				{ 
					bcks[4].values[bcks[4].tam]=array[i];
					bcks[4].tam++;
				}
					else if(array[i]>=auxMAIOR*5  && array[i]<auxMAIOR*6)
				{ 
					bcks[5].values[bcks[5].tam]=array[i];
					bcks[5].tam++;
				}
					else if(array[i]>=auxMAIOR*6  && array[i]<auxMAIOR*7)
				{ 
					bcks[6].values[bcks[6].tam]=array[i];
					bcks[6].tam++;
				}else{
					bcks[7].values[bcks[7].tam]=array[i];
					bcks[7].tam++;
			}
		break;
		
		}
	}
	ordena(bcks,nmbBuckets);
//	for(i=0;i<nmbBuckets;i++)
	//	imprime(bcks[i].tam,bcks[i].values);
}

void ordena(Buckets *a,int num)
{
#pragma omp parallel num_threads(num)
{
	int i,j,aux,menor; 
	int id;
	id=omp_get_thread_num();
	for (i = 0; i < a[id].tam-1; i++)
	{
		menor=i;
		for (j = i+1; j < a[id].tam; j++)
		{
			if (a[id].values[j]<a[id].values[menor])
			{
				menor=j;
			}
		}
		if(i!=menor)
		{
			
			aux=a[id].values[i];
			a[id].values[i]=a[id].values[menor];
			a[id].values[menor]=aux;
		}
	}
	//	imprime(a[id].tam,a[id].values);
}
}

void imprime(int tam, int * a )
{
	int i;
	//printf("COMEÇOU THREAD\n");
		for(i=0;i<tam;i++){
			printf("%d \n",a[i]);
		}
}
