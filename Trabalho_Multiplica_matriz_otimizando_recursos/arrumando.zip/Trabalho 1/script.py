# python script.py | grep -E "granularity|TESTE" &> derp.txt
import os
print "TESTE 1 -- sem otimização e sem vetorização"
for i in range(1,20):
	os.system("gcc -pg -o blo -O0 MultMatSemLeakNAO_OTIMIZADO.c")
	os.system("./blo 1600")
	os.system("gprof -blo  gmon.out")

print "TESTE 2 -- sem otimização e com vetorização de tamanho 4"
for i in range(1,20):
	os.system("gcc -pg -o blo -O0 MultMatSemLeak.c")
	os.system("./blo 1600")
	os.system("gprof -b blo gmon.out")

print "TESTE 3 -- sem otimização e com vetorização de tamanho 8"
for i in range(1,20):
	os.system("gcc -pg -o blo -O0 MultMatSemLeak.c")
	os.system("./blo 1600")
	os.system("gprof -b blo gmon.out")

print "TESTE 4 -- sem otimização e com vetorização de tamanho 16"
for i in range(1,20):
	os.system("gcc -pg -o blo -O0 MultMatSemLeak.c")
	os.system("./blo 1600")
	os.system("gprof -b blo gmon.out")