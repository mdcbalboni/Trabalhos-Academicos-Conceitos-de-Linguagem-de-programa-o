#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void **calcMult();

/*códigos para rodar com gprof
	gcc -pg -o bla -O0 MultMatSemLeak.c
	./bla
	gprof -b bla gmon.out
*/

/*
	gcc -g -o bla -O0 MultMatSemLeak.c
	valgrind --tool=memcheck --leak-check=yes --show-reachable=yes --num-callers=20 --track-fds=yes ./bla
*/

int main(int argc, char *argv[ ])
{
	int i,j,n;
	n = atoi(argv[1]);
	int **mat1,**mat2,**mat3;

	srand(time(NULL));

	/*ALOCAÇÃO DAS MATRIZES*/
	mat1 = calloc(n , sizeof(int*));
	mat2 = calloc(n , sizeof(int*));
	mat3 = calloc(n , sizeof(int*));
	for (i = 0; i < n; i++)
	{
		mat1[i] = calloc(n, sizeof(int*));
		mat3[i] = calloc(n, sizeof(int*));
		mat2[i] = calloc(n, sizeof(int*));
	}

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			mat1[i][j] = rand()%RAND_MAX;
			mat2[i][j] = rand()%RAND_MAX;
		}
	}

	// printf("matriz 1\n");
	// for (i = 0; i < n; i++)
	// {
	// 	for (j = 0; j < m; j++)
	// 	{
	// 		printf("%d ", mat1[i][j]);
	// 	}
	// 	printf("\n");
	// }

	// printf("matriz 2\n");
	// for (i = 0; i < m; i++)
	// {
	// 	for (j = 0; j < z; j++)
	// 	{
	// 		printf("%d ", mat2[i][j]);
	// 	}
	// 	printf("\n");
	// }

	calcMult(mat1, mat2, mat3, n);

	// printf("matriz resultante\n");
	// for (i = 0; i < n; i++)
	// {
	// 	for (j = 0; j < z; j++)
	// 	{
	// 		printf("%d ", mat3[i][j]);
	// 	}
	// 	printf("\n");
	// }

	for (i = 0; i < n; i++)
	{
		free(mat1[i]);
	}
	free(mat1);
	for (i = 0; i < n; i++)
	{
		free(mat2[i]);
	}
	free(mat2);
	for (i = 0; i < n; i++)
	{
		free(mat3[i]);
	}
	free(mat3);

	return 0;
}

void **calcMult (int **A, int **B, int **C, int n)
{
	int i,j,k;
	
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			C[i][j] = 0;
			for (k = 0; k < n; k++)
			{	
				C[i][j] += A[i][k] * B[k][j];
			}
		}
	}

}
